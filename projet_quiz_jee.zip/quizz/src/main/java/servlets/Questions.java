package servlets;
public class Questions {
    public int question_number;
    public String question;
    public String[] answers;
    public int correct_answer_index;
    public int selected_answer_index = -1;
    
    public Questions(String question,String[] answers,int correct_answer_index){
        this.question = question;
        this.answers = answers;
        this.correct_answer_index = correct_answer_index;
    }
    
    
    public String[] getAnswers() {
        return answers;
    }
}
