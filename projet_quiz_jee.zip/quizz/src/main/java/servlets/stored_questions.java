package servlets;

public class stored_questions {
    public static Questions[] Questions = new Questions[11];
}
