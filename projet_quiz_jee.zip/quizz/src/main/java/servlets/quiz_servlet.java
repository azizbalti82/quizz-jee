package servlets;



import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class quiz_servlet extends HttpServlet {
    ServletContext c = null;
    
    public void destroy(){
        //reset questions:
        c.setAttribute("current_question",1);
        
    }
    public void init(){
        c = getServletConfig().getServletContext();
        
        // Question 1
        String[] q1Answers = {"Java Environnement d'Exécution", "Java Édition Entreprise", "Java Environnement Essentiel", "Java Extension d'Amélioration"};
        Questions question1 = new Questions("Que signifie l'acronyme JEE ?", q1Answers, 1);
        
        // Question 2
        String[] q2Answers = {"Servlet", "JSP (JavaServer Pages)", "JDBC (Java Database Connectivity)", "JVM (Java Virtual Machine)"};
        Questions question2 = new Questions("Quel composant suivant n'est pas une composante principale de JEE ?", q2Answers, 3);
        
        // Question 3
        String[] q3Answers = {"EJB (Enterprise JavaBeans)", "JMS (Java Message Service)", "JSF (JavaServer Faces)", "JPA (Java Persistence API)"};
        Questions question3 = new Questions("Quelle technologie JEE est utilisée pour construire des applications web dynamiques ?", q3Answers, 2);
        
        // Question 4
        String[] q4Answers = {"JTA (Java Transaction API)", "JMS (Java Message Service)", "JPA (Java Persistence API)", "JAXB (Java Architecture for XML Binding)"};
        Questions question4 = new Questions("Quelle API est utilisée pour interagir avec les bases de données relationnelles en JEE ?", q4Answers, 2);
        
        // Question 5
        String[] q5Answers = {"HTTP", "TCP", "SMTP", "UDP"};
        Questions question5 = new Questions("Quel protocole est communément utilisé pour la communication entre les serveurs web et les conteneurs de servlets ?", q5Answers, 0);
        
        // Question 6
        String[] q6Answers = {"@Servlet", "@WebServlet", "@ServletMapping", "@ServletConfig"};
        Questions question6 = new Questions("Quelle annotation suivante est utilisée pour déclarer un servlet en JEE ?", q6Answers, 1);
        
        // Question 7
        String[] q7Answers = {"Conteneur EJB", "Conteneur Servlet", "JTA (Java Transaction API)", "JPA (Java Persistence API)"};
        Questions question7 = new Questions("Quel composant est responsable de la gestion des transactions dans les applications JEE ?", q7Answers, 2);
        
        // Question 8
        String[] q8Answers = {"Spécifier la version de Java utilisée dans l'application", "Configurer les servlets, filtres et autres composants de l'application", "Définir la structure des pages web en utilisant des balises HTML", "Stocker les informations de connexion à la base de données"};
        Questions question8 = new Questions("Quel est le but du descripteur de déploiement (web.xml) dans une application web JEE ?", q8Answers, 1);
        
        // Question 9
        String[] q9Answers = {"JPA (Java Persistence API)", "JTA (Java Transaction API)", "JMS (Java Message Service)", "JSP (JavaServer Pages)"};
        Questions question9 = new Questions("Quelle technologie JEE est utilisée pour la messagerie asynchrone ?", q9Answers, 2);
        
        // Question 10
        String[] q10Answers = {"Réécriture d'URL", "Champs de formulaire cachés", "ServletContext", "HttpSession"};
        Questions question10 = new Questions("Lequel des éléments suivants n'est pas une technique de gestion de session valide dans les applications web JEE ?", q10Answers, 2);
        
        
        //SAVE QUESTION to servletContext
        c.setAttribute("question1",question1);
        c.setAttribute("question2",question2);
        c.setAttribute("question3",question3);
        c.setAttribute("question4",question4);
        c.setAttribute("question5",question5);
        c.setAttribute("question6",question6);
        c.setAttribute("question7",question7);
        c.setAttribute("question8",question8);
        c.setAttribute("question9",question9);
        c.setAttribute("question10",question10);
        
        //save current question number (default 1)
        c.setAttribute("current_question",1);
    }

    private Questions getQuestion(int number){
        c = getServletConfig().getServletContext();
        try{
        Questions q = null;
        
        switch(number){
            case 1: q = (Questions) c.getAttribute("question1");break;
            case 2: q = (Questions) c.getAttribute("question2");break;
            case 3: q = (Questions) c.getAttribute("question3");break;
            case 4: q = (Questions) c.getAttribute("question4");break;
            case 5: q = (Questions) c.getAttribute("question5");break;
            case 6: q = (Questions) c.getAttribute("question6");break;
            case 7: q = (Questions) c.getAttribute("question7");break;
            case 8: q = (Questions) c.getAttribute("question8");break;
            case 9: q = (Questions) c.getAttribute("question9");break;
            case 10: q = (Questions) c.getAttribute("question10");break;
        }
        
        return q;
        }catch(Exception e){
            return null;
        }
    }
    
    private void updateQuestion(int number,Questions selected){
        c = getServletConfig().getServletContext();
        try{
            switch(number){
                case 1: c.setAttribute("question1",selected);break;
                case 2: c.setAttribute("question2",selected);break;
                case 3: c.setAttribute("question3",selected);break;
                case 4: c.setAttribute("question4",selected);break;
                case 5: c.setAttribute("question5",selected);break;
                case 6: c.setAttribute("question6",selected);break;
                case 7: c.setAttribute("question7",selected);break;
                case 8: c.setAttribute("question8",selected);break;
                case 9: c.setAttribute("question9",selected);break;
                case 10: c.setAttribute("question10",selected);break;
            }
        }catch(Exception e){
        }
    }
    
    
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        
        //get current question index:
        int question_number = (int) c.getAttribute("current_question");
        
        //increment question when an option is selected
        String last_answer = req.getParameter("answer");
        if(last_answer != null){
            int answer = Integer.parseInt(last_answer);
            //get question object and edit selected answer:
            Questions x = getQuestion(question_number);
            x.selected_answer_index = answer;
            updateQuestion(question_number,x);
            
            c.setAttribute("current_question",question_number+1);
            question_number = (int) c.getAttribute("current_question");
            
            
            //if we reached the end: open result.jsp page:
            if(question_number > 10){
                //get all questions & answers and save them in the request:
                
                for(int i=0;i<10;i++){
                    stored_questions.Questions[i] = getQuestion(i+1);
                }
                //req.setAttribute("questions",questions);
                
                //open result file
                RequestDispatcher r = req.getRequestDispatcher("/result.jsp");
        
                res.reset();
                r.forward(req, res);
                
                //destroy this servlet(bch ki naaml repeter taaml init() meloul
                this.destroy();
                
            }
            
        }

        //get question object
        Questions q = getQuestion(question_number);

        
        res.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = res.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet quiz_servlet</title>");            
            out.println("</head>");
            out.println("<body face='Arial, sans-serif' >");
            out.println("<center>");
            out.println("<h1>Question N°"+String.valueOf(question_number)+"</h1>");
            out.println("<form action='/quizz/quiz_servlet' method='get'>");
            
            //questions
            out.println("<table>");
            out.println("<tr><td colspan='2'> "+q.question+"<br><br></td></tr>");
            
            
            //options (answers)
            out.println("<tr><td> <input type='radio' name='answer' value='0'/>"+q.answers[0]+"</td></tr>");
            out.println("<tr><td> <input type='radio' name='answer' value='1'/>"+q.answers[1]+"</td></tr>");
            out.println("<tr><td> <input type='radio' name='answer' value='2'/>"+q.answers[2]+"</td></tr>");
            out.println("<tr><td> <input type='radio' name='answer' value='3'/>"+q.answers[3]+"</td></tr>");

           
            out.println("</table>");
            //submit
            out.println("<br><br><input type='submit' value='Suivant'>");
            
            out.println("</form>");
  
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
        }catch(Exception e){
            
        }
        
        
    }
}
